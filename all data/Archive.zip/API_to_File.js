let request = require("request");
let fs = require("fs");

request(
  "http://api.e-stat.go.jp/rest/2.1/app/json/getStatsData?appId=9cbfca2625feb0613d943d05f91e7cf4118b0a19&lang=E&statsDataId=0003097041&metaGetFlg=Y&cntGetFlg=N&sectionHeaderFlg=2&cdTime=2017000101"
).pipe(fs.createWriteStream("January2017.json"));
